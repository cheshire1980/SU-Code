﻿using UnityEngine;
using System.Collections;

public class inLogin_playmakerVariable : MonoBehaviour {



	[HideInInspector]
	public string onlineVariableName = ""; //to Get Or Set this variable with Playmaker
	[HideInInspector]
	public string onlineVariableValue = ""; //SET
	[HideInInspector]
	public string onlineVariableResult = ""; //GET






	public void getOnlineVariable() {
		global.PM_VariableState = 0;
		StartCoroutine( GetOnlineVariable(onlineVariableName) ); //(****SAME AS THE ONLINE DATABASE****)
	}


	public void setOnlineVariable() {
		global.PM_VariableState = 0;
		StartCoroutine( SetOnlineVariable(onlineVariableName, onlineVariableValue) ); //(****SAME AS THE ONLINE DATABASE****)
	}






	
	
	public IEnumerator GetOnlineVariable(string myVarToGet) { //myVarToGet = SAME AS THE ONLINE DATABASE)
		
		WWWForm form = new WWWForm(); //here you create a new form connection

		form.AddField( "PHP_hash", global.gameHashCode ); //your hash
		
		form.AddField( "PHP_username", global.username ); //joueur connecter
		
		form.AddField( "PHP_password", global.userpassword ); //joueur connecter
		
		form.AddField( "PHP_variable", myVarToGet ); //enter your variable name here (****SAME AS THE ONLINE DATABASE****)
		
		form.AddField( "PHP_action", "GetVariable" );


		WWW w = new WWW(global.URL_GetSetVariable , form); //here we create a var called 'w' and we sync with our URL and the form
		
		yield return w;
		
		if (w.error != null) {

			//ERROR
			global.PM_VariableState = 2;

		} else {

			//SUCCESS
			global.PM_VariableState = 1;
			Debug.Log( w.text );
			if(w.text.Length > 0) {
				onlineVariableResult = w.text; 
			}

			
			w.Dispose(); 
			
		}
		
	} 






	
	public IEnumerator SetOnlineVariable(string myVarToGet, string varValue) {  //myVarToGet = SAME AS THE ONLINE DATABASE)
		
		WWWForm form = new WWWForm(); //here you create a new form connection
		
		form.AddField( "PHP_hash", global.gameHashCode ); //your hash
		
		form.AddField( "PHP_username", global.username ); //joueur connecter
		
		form.AddField( "PHP_password", global.userpassword ); //joueur connecter
		
		form.AddField( "PHP_variable", myVarToGet ); //enter your variable name here (****SAME AS THE ONLINE DATABASE****)

		form.AddField( "PHP_varValue", varValue ); //enter your variable name here (****SAME AS THE ONLINE DATABASE****)

		form.AddField( "PHP_action", "SetVariable" ); 

		
		WWW w = new WWW(global.URL_GetSetVariable , form); //here we create a var called 'w' and we sync with our URL and the form
		
		yield return w;
		
		if (w.error != null) {
			
			//ERROR
			global.PM_VariableState = 2;
			
		} else {
			
			//SUCCESS
			Debug.Log( "success: "+w.text );
			global.PM_VariableState = 1;

			w.Dispose(); 
			
		}
		
	} 









}
