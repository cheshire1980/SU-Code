// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("inLogin")]
	[Tooltip("Login with a usernam and password.")]
	
	public class inLogin_register : FsmStateAction
	{
		
		//dire quon doit changer la game version dans global.cs
		//hashcode aussi
		
		
		[RequiredField]
		[Tooltip("Thow Owner Of the loginMenu.cs script for start the connection.")]
		public FsmOwnerDefault OwnerOfLoginMenuScript;
		
		public FsmString username;
		public FsmString password;
		public FsmString confirmPassword;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		
		public override void Reset()
		{
			OwnerOfLoginMenuScript = null;
			username = "";
			password = "";
			successEvent = null;
			failEvent = null;
		}
		
		
		
		public override void OnEnter()
		{
			
			var go = Fsm.GetOwnerDefaultTarget(OwnerOfLoginMenuScript);
			
			if (go == null)
			{
				return;
			}
			
			global.PM_ConnectionState = 0;
			go.GetComponent<loginMenu>().formNickREG = username.Value;
			go.GetComponent<loginMenu>().formPasswordREG = password.Value;
			go.GetComponent<loginMenu>().formConfirmPasswordREG = confirmPassword.Value;
			go.SendMessage("registerFromPlaymaker");
			
			
		}
		
		
		public override void OnUpdate()
		{
			//Debug.Log("test");
			if(global.PM_ConnectionState == 1) { //succes
				Fsm.Event(successEvent);
			}
			else if(global.PM_ConnectionState == 2) { //fail
				Fsm.Event(failEvent);
			}
		}
		
	}
}