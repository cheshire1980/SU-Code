// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("inLogin")]
	[Tooltip("Get Online Float. NOTE: You need to be logged in before set/get variable.")]

	public class inLogin_getFloat : FsmStateAction
	{

		//dire quon doit changer la game version dans global.cs
		//hashcode aussi


		[RequiredField]
		[Tooltip("Show the Owner Of the playmakerVariable.cs script for start the connection.")]
		public FsmOwnerDefault OwnerOfLoginMenuScript;

		public FsmString variableName;
		//public FsmString stringValue;
		public FsmFloat resultFloat;

		public FsmEvent successEvent;
		public FsmEvent failEvent;



		public override void Reset()
		{
			OwnerOfLoginMenuScript = null;
			variableName = "";
			resultFloat = 0f;
			successEvent = null;
			failEvent = null;
		}



		public override void OnEnter()
		{

			var go = Fsm.GetOwnerDefaultTarget(OwnerOfLoginMenuScript);

			if (go == null)
			{
				return;
			}

			global.PM_VariableState = 0;
			go.GetComponent<inLogin_playmakerVariable>().onlineVariableName = variableName.Value;
			go.SendMessage("getOnlineVariable");


		}


		public override void OnUpdate()
		{
			//Debug.Log("test");
			if(global.PM_VariableState == 1) { //succes

				var go = Fsm.GetOwnerDefaultTarget(OwnerOfLoginMenuScript);
				if (go == null)
				{ return; }
				resultFloat = float.Parse( go.GetComponent<inLogin_playmakerVariable>().onlineVariableResult.ToString() );

				Fsm.Event(successEvent);
			}
			else if(global.PM_VariableState == 2) { //fail
				Fsm.Event(failEvent);
			}
		}

	}
}