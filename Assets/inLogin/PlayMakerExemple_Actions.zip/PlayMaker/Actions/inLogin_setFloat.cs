// (c) Copyright HutongGames, LLC 2010-2012. All rights reserved.

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("inLogin")]
	[Tooltip("Set Online Float. NOTE: You need to be logged in before set/get variable.")]

	public class inLogin_setFloat : FsmStateAction
	{

		//dire quon doit changer la game version dans global.cs
		//hashcode aussi


		[RequiredField]
		[Tooltip("Show the Owner Of the playmakerVariable.cs script for start the connection.")]
		public FsmOwnerDefault OwnerOfLoginMenuScript;

		public FsmString variableName;
		public FsmFloat floatValue;
		//public FsmString resultString;

		public FsmEvent successEvent;
		public FsmEvent failEvent;



		public override void Reset()
		{
			OwnerOfLoginMenuScript = null;
			variableName = "";
			floatValue = 0;
			successEvent = null;
			failEvent = null;
		}



		public override void OnEnter()
		{

			var go = Fsm.GetOwnerDefaultTarget(OwnerOfLoginMenuScript);

			if (go == null)
			{
				return;
			}

			global.PM_VariableState = 0;
			go.GetComponent<inLogin_playmakerVariable>().onlineVariableName = variableName.Value;
			go.GetComponent<inLogin_playmakerVariable>().onlineVariableValue = floatValue.Value.ToString();
			go.SendMessage("setOnlineVariable");


		}


		public override void OnUpdate()
		{
			//Debug.Log("test");
			if(global.PM_VariableState == 1) { //succes
				Fsm.Event(successEvent);
			}
			else if(global.PM_VariableState == 2) { //fail
				Fsm.Event(failEvent);
			}
		}

	}
}